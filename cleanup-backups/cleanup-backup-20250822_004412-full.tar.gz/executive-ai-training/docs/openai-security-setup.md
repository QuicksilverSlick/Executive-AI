# OpenAI API Security Configuration Guide

## Overview

This guide covers the secure configuration of OpenAI API keys for the voice agent implementation, including best practices for development and production environments.

## ✅ Completed Configuration

### 1. Environment Variables Setup

**File: `.env.local`** (created)
```bash
# OpenAI Configuration
OPENAI_API_KEY=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

# Voice Agent Configuration
ALLOWED_ORIGINS=http://localhost:4321,https://executiveaitraining.com
VOICE_AGENT_RATE_LIMIT=10
VOICE_AGENT_TOKEN_DURATION=60
```

### 2. Git Security (Updated .gitignore)

Added comprehensive environment file exclusion:
```gitignore
# environment variables
.env
.env.local
.env.development
.env.production
*.env
```

### 3. Verification Scripts

- **`scripts/verify-openai-setup.js`**: Tests API key validity and OpenAI connectivity
- **`scripts/test-token-endpoint.js`**: Tests the local token generation endpoint
- **New npm scripts**: `verify-openai`, `test-token`, `setup-check`

## 🔒 Security Features Implemented

### API Endpoint Security (`/api/voice-agent/token.ts`)

1. **Rate Limiting**: 10 requests per minute per IP
2. **CORS Protection**: Only allowed origins can access the endpoint
3. **Short-lived Tokens**: 60-second expiration by default
4. **Request Logging**: All requests logged with IP and user agent
5. **Error Handling**: Secure error messages, no sensitive data exposure

### Token Management

- **Ephemeral Tokens**: Generated on-demand with short lifespan
- **Session Tracking**: Each token tied to a unique session ID
- **Automatic Expiration**: Tokens expire after 60 seconds

## 🧪 Testing Your Setup

### Quick Verification
```bash
npm run setup-check
```

### Detailed API Testing
```bash
npm run verify-openai  # Test OpenAI API connectivity
npm run test-token     # Test local token endpoint
```

### Manual Testing
```bash
# Start the development server
npm run dev

# Test the token endpoint directly
curl -X POST http://localhost:4321/api/voice-agent/token \
  -H "Content-Type: application/json" \
  -H "Origin: http://localhost:4321"
```

## 🚀 Deployment Considerations

### Production Environment Variables

For production, set these environment variables on your hosting platform:

```bash
OPENAI_API_KEY=your-production-api-key
ALLOWED_ORIGINS=https://executiveaitraining.com,https://www.executiveaitraining.com
VOICE_AGENT_RATE_LIMIT=5  # More restrictive in production
VOICE_AGENT_TOKEN_DURATION=30  # Shorter duration in production
NODE_ENV=production
```

### Security Checklist

- [ ] ✅ API key stored in environment variables only
- [ ] ✅ Environment files excluded from version control
- [ ] ✅ Rate limiting configured
- [ ] ✅ CORS properly configured
- [ ] ✅ Short token expiration times
- [ ] ✅ Request logging enabled
- [ ] [ ] SSL/TLS enabled (production)
- [ ] [ ] Monitoring and alerting setup (production)

## 🛠 Troubleshooting

### Common Issues

1. **"Service temporarily unavailable"**
   - Check if `.env.local` exists
   - Verify `OPENAI_API_KEY` is set correctly

2. **"Invalid origin" errors**
   - Check `ALLOWED_ORIGINS` includes your domain
   - Ensure no typos in origin URLs

3. **Rate limit exceeded**
   - Increase `VOICE_AGENT_RATE_LIMIT` if needed
   - Check for excessive requests from same IP

4. **Token generation fails**
   - Verify OpenAI API key has Realtime API access
   - Check your OpenAI account billing status

### Debug Commands

```bash
# Check environment variables
node -e "console.log(process.env.OPENAI_API_KEY ? 'API Key loaded' : 'API Key missing')"

# Test direct OpenAI connection
curl -H "Authorization: Bearer YOUR_API_KEY" https://api.openai.com/v1/models

# Check server logs
npm run dev  # Look for startup messages
```

## 📚 Additional Resources

- [OpenAI API Documentation](https://platform.openai.com/docs)
- [Realtime API Guide](https://platform.openai.com/docs/guides/realtime)
- [Security Best Practices](https://platform.openai.com/docs/guides/safety-best-practices)

## 🔄 Next Steps

1. Run the verification scripts to ensure everything works
2. Test the voice agent in a browser at `http://localhost:4321`
3. Check browser console for any authentication errors
4. Configure production environment variables when deploying

---

**Status**: ✅ **COMPLETE** - OpenAI API key is securely configured and ready for use.