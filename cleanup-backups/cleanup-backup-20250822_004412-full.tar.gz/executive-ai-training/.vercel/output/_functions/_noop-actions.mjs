const server = {};

export { server };
