/* empty css                                 */
import { e as createComponent, f as createAstro, ak as renderHead, r as renderTemplate } from '../chunks/astro/server_BUcCHCB2.mjs';
import 'kleur/colors';
import 'clsx';
export { renderers } from '../renderers.mjs';

const $$Astro = createAstro();
const $$TestPage = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$TestPage;
  return renderTemplate`<html lang="en"> <head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>Test Page</title>${renderHead()}</head> <body> <h1>Test Page</h1> <p>If you can see this, static pages are working!</p> <p>Time: ${(/* @__PURE__ */ new Date()).toISOString()}</p> <h2>API Test Links:</h2> <ul> <li><a href="/api/hello">/api/hello (native Vercel function)</a></li> <li><a href="/api/simple">/api/simple (Astro JS endpoint)</a></li> <li><a href="/api/test">/api/test (Astro TS endpoint)</a></li> <li><a href="/api/health">/api/health (health check)</a></li> </ul> </body></html>`;
}, "/home/dreamforge/ai_masterclass/executive-ai-training/src/pages/test-page.astro", void 0);

const $$file = "/home/dreamforge/ai_masterclass/executive-ai-training/src/pages/test-page.astro";
const $$url = "/test-page";

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: $$TestPage,
    file: $$file,
    url: $$url
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
