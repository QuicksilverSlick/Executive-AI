import { _ as _page } from '../../../chunks/refresh-token_B3YlMXTR.mjs';
export { renderers } from '../../../renderers.mjs';

const page = () => _page;

export { page };
