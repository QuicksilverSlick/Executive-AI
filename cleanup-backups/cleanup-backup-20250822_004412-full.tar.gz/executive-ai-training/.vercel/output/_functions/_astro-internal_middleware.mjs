import { d as defineMiddleware, s as sequence } from './chunks/index_C9nDm-uB.mjs';
import 'es-module-lexer';
import './chunks/astro-designed-error-pages_BKu1Vypp.mjs';
import 'kleur/colors';
import './chunks/astro/server_BUcCHCB2.mjs';
import 'clsx';
import 'cookie';

const onRequest$1 = defineMiddleware(async (context, next) => {
  if (context.url.pathname.startsWith("/api/")) {
    const response = await next();
    const newResponse = new Response(response.body, response);
    newResponse.headers.set("Access-Control-Allow-Origin", "*");
    newResponse.headers.set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
    newResponse.headers.set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    if (context.request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: newResponse.headers
      });
    }
    return newResponse;
  }
  return next();
});

const onRequest = sequence(
	
	onRequest$1
	
);

export { onRequest };
