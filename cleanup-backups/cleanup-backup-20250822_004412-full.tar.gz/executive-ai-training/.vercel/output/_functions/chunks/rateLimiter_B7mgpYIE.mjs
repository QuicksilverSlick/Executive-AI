const __vite_import_meta_env__ = {"ASSETS_PREFIX": undefined, "BASE_URL": "/", "DEV": false, "MODE": "production", "PROD": true, "PUBLIC_CALENDLY_URL": "https://calendly.com/your-username", "PUBLIC_GA_MEASUREMENT_ID": "G-XXXXXXXXXX", "PUBLIC_SITE_NAME": "Executive AI Training", "PUBLIC_SITE_URL": "https://executiveaitraining.com", "SITE": undefined, "SSR": true};
class AdvancedRateLimiter {
  constructor(config) {
    this.config = config;
    this.cleanupInterval = setInterval(() => {
      this.cleanup();
    }, 5 * 60 * 1e3);
  }
  store = /* @__PURE__ */ new Map();
  cleanupInterval;
  suspiciousIPs = /* @__PURE__ */ new Set();
  /**
   * Check if request is allowed under rate limit
   */
  checkLimit(request, clientIP) {
    if (this.config.whitelist && this.isWhitelisted(clientIP)) {
      return {
        allowed: true,
        remaining: this.config.maxRequests,
        resetTime: Date.now() + this.config.windowMs,
        warning: this.config.isDevelopment ? "Development mode - rate limiting bypassed" : void 0
      };
    }
    const key = this.config.keyGenerator ? this.config.keyGenerator(request, clientIP) : clientIP;
    const now = Date.now();
    const windowStart = now - this.config.windowMs;
    let info = this.store.get(key);
    if (!info || info.resetTime <= now) {
      info = {
        count: 1,
        resetTime: now + this.config.windowMs,
        windowStart: now,
        suspiciousActivity: false
      };
      this.store.set(key, info);
      return {
        allowed: true,
        remaining: this.config.maxRequests - 1,
        resetTime: info.resetTime
      };
    }
    if (info.windowStart <= windowStart) {
      info.windowStart = windowStart;
      info.count = Math.max(1, Math.floor(info.count * 0.8));
    }
    const suspiciousThreshold = this.config.suspiciousThreshold || (this.config.isDevelopment ? 0.95 : 0.8);
    if (info.count >= this.config.maxRequests * suspiciousThreshold) {
      this.detectSuspiciousActivity(key, clientIP, info);
    }
    if (info.count >= this.config.maxRequests) {
      if (this.config.onLimitReached) {
        this.config.onLimitReached(clientIP, info.count);
      }
      const retryAfter = Math.ceil((info.resetTime - now) / 1e3);
      return {
        allowed: false,
        remaining: 0,
        resetTime: info.resetTime,
        retryAfter,
        warning: info.suspiciousActivity ? "Suspicious activity detected" : void 0
      };
    }
    info.count++;
    return {
      allowed: true,
      remaining: this.config.maxRequests - info.count,
      resetTime: info.resetTime
    };
  }
  /**
   * Check if IP is whitelisted
   */
  isWhitelisted(clientIP) {
    if (!this.config.whitelist) return false;
    return this.config.whitelist.some((whitelistedIP) => {
      if (whitelistedIP === clientIP) return true;
      if (whitelistedIP === "localhost" && (clientIP === "127.0.0.1" || clientIP === "::1" || clientIP === "localhost")) {
        return true;
      }
      if (whitelistedIP === "127.0.0.1" && (clientIP === "localhost" || clientIP === "::1")) {
        return true;
      }
      return false;
    });
  }
  /**
   * Detect suspicious activity patterns
   */
  detectSuspiciousActivity(key, clientIP, info) {
    if (this.config.isDevelopment && this.isWhitelisted(clientIP)) {
      return;
    }
    const threshold = this.config.suspiciousThreshold || (this.config.isDevelopment ? 0.95 : 0.9);
    if (info.count >= this.config.maxRequests * threshold) {
      info.suspiciousActivity = true;
      this.suspiciousIPs.add(clientIP);
      if (this.config.isDevelopment) {
        console.log(`⚠️ High activity detected from ${clientIP} - Key: ${key} (Development mode)`);
      } else {
        console.warn(`🚨 Suspicious activity detected from ${clientIP} - Key: ${key}`);
      }
    }
  }
  /**
   * Check if IP is marked as suspicious
   */
  isSuspicious(clientIP) {
    return this.suspiciousIPs.has(clientIP);
  }
  /**
   * Clean up expired entries and suspicious IPs
   */
  cleanup() {
    const now = Date.now();
    let cleaned = 0;
    for (const [key, info] of this.store.entries()) {
      if (info.resetTime <= now) {
        this.store.delete(key);
        cleaned++;
      }
    }
    const suspiciousCleanupTime = now - 60 * 60 * 1e3;
    for (const ip of this.suspiciousIPs) {
      const info = this.store.get(ip);
      if (!info || info.resetTime <= suspiciousCleanupTime) {
        this.suspiciousIPs.delete(ip);
      }
    }
    if (cleaned > 0) {
      console.log(`🧹 Rate limiter cleanup: removed ${cleaned} expired entries`);
    }
  }
  /**
   * Get current statistics
   */
  getStats() {
    return {
      totalEntries: this.store.size,
      suspiciousIPs: this.suspiciousIPs.size
    };
  }
  /**
   * Manually reset rate limit for a specific key
   */
  resetLimit(key) {
    return this.store.delete(key);
  }
  /**
   * Clear all rate limits (development only)
   */
  clearAllLimits() {
    if (!this.config.isDevelopment) {
      console.warn("⚠️ clearAllLimits() can only be used in development mode");
      return false;
    }
    const clearedEntries = this.store.size;
    const clearedSuspicious = this.suspiciousIPs.size;
    this.store.clear();
    this.suspiciousIPs.clear();
    console.log(`🧹 Development: Cleared ${clearedEntries} rate limit entries and ${clearedSuspicious} suspicious IPs`);
    return true;
  }
  /**
   * Remove IP from suspicious list
   */
  clearSuspiciousIP(clientIP) {
    return this.suspiciousIPs.delete(clientIP);
  }
  /**
   * Destroy the rate limiter and clean up resources
   */
  destroy() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
    }
    this.store.clear();
    this.suspiciousIPs.clear();
  }
}
function createTokenRateLimiter(customConfig) {
  const isDevelopment = typeof process !== "undefined" && process.env?.NODE_ENV === "development" || typeof globalThis !== "undefined" && globalThis.import?.meta?.env?.DEV === true || typeof import.meta !== "undefined" && Object.assign(__vite_import_meta_env__, { NODE_ENV: process.env.NODE_ENV, _: process.env._, NODE: process.env.NODE })?.DEV === true || typeof window !== "undefined";
  const defaultConfig = {
    windowMs: 60 * 1e3,
    // 1 minute window
    maxRequests: isDevelopment ? 50 : 10,
    // More lenient in development
    skipSuccessfulRequests: false,
    isDevelopment,
    whitelist: isDevelopment ? [
      "localhost",
      "127.0.0.1",
      "::1",
      "0.0.0.0",
      "unknown"
      // For cases where IP detection fails in development
    ] : [],
    suspiciousThreshold: isDevelopment ? 0.95 : 0.8,
    keyGenerator: (request, clientIP) => {
      const userAgent = request.headers.get("user-agent") || "";
      const userAgentHash = userAgent.substring(0, 10);
      return `${clientIP}:${userAgentHash}`;
    },
    onLimitReached: (clientIP, attempts) => {
      if (isDevelopment) {
        console.log(`ℹ️ Rate limit reached for ${clientIP} - Attempts: ${attempts} (Development mode)`);
      } else {
        console.warn(`🚫 Rate limit exceeded for ${clientIP} - Attempts: ${attempts}`);
      }
    }
  };
  return new AdvancedRateLimiter({ ...defaultConfig, ...customConfig });
}
function createProxyRateLimiter(customConfig) {
  const isDevelopment = typeof process !== "undefined" && process.env?.NODE_ENV === "development" || typeof globalThis !== "undefined" && globalThis.import?.meta?.env?.DEV === true || typeof import.meta !== "undefined" && Object.assign(__vite_import_meta_env__, { NODE_ENV: process.env.NODE_ENV, _: process.env._, NODE: process.env.NODE })?.DEV === true;
  const defaultConfig = {
    windowMs: 60 * 1e3,
    // 1 minute window
    maxRequests: isDevelopment ? 200 : 50,
    // Higher limits for proxy requests
    skipSuccessfulRequests: false,
    isDevelopment,
    whitelist: isDevelopment ? [
      "localhost",
      "127.0.0.1",
      "::1",
      "0.0.0.0",
      "unknown"
    ] : [],
    suspiciousThreshold: isDevelopment ? 0.95 : 0.8,
    keyGenerator: (request, clientIP) => {
      const authHeader = request.headers.get("authorization");
      const sessionHint = authHeader ? authHeader.substring(-8) : "";
      return `proxy:${clientIP}:${sessionHint}`;
    },
    onLimitReached: (clientIP, attempts) => {
      console.warn(`🚫 Proxy rate limit exceeded for ${clientIP} - Attempts: ${attempts}`);
    }
  };
  return new AdvancedRateLimiter({ ...defaultConfig, ...customConfig });
}
function createRateLimitMiddleware(rateLimiter) {
  return (request, clientIP) => {
    const result = rateLimiter.checkLimit(request, clientIP);
    if (!result.allowed) {
      const headers = {
        "Content-Type": "application/json",
        "X-RateLimit-Limit": rateLimiter["config"].maxRequests.toString(),
        "X-RateLimit-Remaining": result.remaining.toString(),
        "X-RateLimit-Reset": Math.ceil(result.resetTime / 1e3).toString()
      };
      if (result.retryAfter) {
        headers["Retry-After"] = result.retryAfter.toString();
      }
      return new Response(JSON.stringify({
        success: false,
        error: "Rate limit exceeded. Please try again later.",
        retryAfter: result.retryAfter,
        warning: result.warning
      }), {
        status: 429,
        headers
      });
    }
    return null;
  };
}

export { createProxyRateLimiter as a, createRateLimitMiddleware as b, createTokenRateLimiter as c };
