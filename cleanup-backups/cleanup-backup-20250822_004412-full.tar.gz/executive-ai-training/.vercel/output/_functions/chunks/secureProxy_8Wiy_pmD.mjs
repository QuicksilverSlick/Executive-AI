import crypto from 'crypto';

const PRODUCTION_CONFIG = {
  cors: {
    allowedOrigins: [
      "https://executiveaitraining.com",
      "https://www.executiveaitraining.com"
    ],
    allowedMethods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
    maxAge: 86400,
    // 24 hours
    credentials: false
  },
  rateLimit: {
    windowMs: 60 * 1e3,
    // 1 minute
    maxRequests: 5,
    // Conservative limit for production
    maxRequestsPerSession: 20,
    // Max refreshes per session
    suspiciousActivityThreshold: 3,
    // Flag after 3 near-limit attempts
    blockDuration: 15 * 60 * 1e3
    // 15 minutes
  },
  token: {
    defaultDuration: 60,
    // 60 seconds
    maxDuration: 120,
    // Max 2 minutes
    minRefreshInterval: 30 * 1e3,
    // 30 seconds between refreshes
    maxRefreshAttempts: 10
    // Max 10 refreshes per session
  },
  headers: {
    security: {
      "X-Content-Type-Options": "nosniff",
      "X-Frame-Options": "DENY",
      "X-XSS-Protection": "1; mode=block",
      "Referrer-Policy": "strict-origin-when-cross-origin",
      "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
      "Content-Security-Policy": "default-src 'none'; connect-src 'self'"
    },
    cache: {
      "Cache-Control": "no-cache, no-store, must-revalidate",
      "Pragma": "no-cache",
      "Expires": "0"
    }
  },
  monitoring: {
    logLevel: "warn",
    enableMetrics: true,
    enableAuditLog: true,
    retentionDays: 30
  },
  validation: {
    enableStrictValidation: true,
    requireUserAgent: true,
    enableGeoBlocking: false,
    blockedCountries: []
  }
};
const DEVELOPMENT_CONFIG = {
  cors: {
    allowedOrigins: [
      "http://localhost:4321",
      "http://localhost:4322",
      "http://localhost:3000",
      "http://127.0.0.1:4321",
      "https://executiveaitraining.com"
    ],
    allowedMethods: ["GET", "POST", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
    maxAge: 300,
    // 5 minutes
    credentials: false
  },
  rateLimit: {
    windowMs: 60 * 1e3,
    // 1 minute
    maxRequests: 100,
    // Very lenient for development
    maxRequestsPerSession: 200,
    suspiciousActivityThreshold: 50,
    // Much higher threshold in development
    blockDuration: 1 * 60 * 1e3
    // 1 minute only
  },
  token: {
    defaultDuration: 60,
    // 60 seconds
    maxDuration: 300,
    // Max 5 minutes for development
    minRefreshInterval: 10 * 1e3,
    // 10 seconds between refreshes
    maxRefreshAttempts: 50
  },
  headers: {
    security: {
      "X-Content-Type-Options": "nosniff"
    },
    cache: {
      "Cache-Control": "no-cache, no-store, must-revalidate"
    }
  },
  monitoring: {
    logLevel: "debug",
    enableMetrics: true,
    enableAuditLog: false,
    retentionDays: 7
  },
  validation: {
    enableStrictValidation: false,
    requireUserAgent: false,
    enableGeoBlocking: false,
    blockedCountries: []
  }
};
function getSecurityConfig() {
  const isDevelopment = process.env.NODE_ENV === "development";
  return isDevelopment ? DEVELOPMENT_CONFIG : PRODUCTION_CONFIG;
}
function validateOrigin(origin, config) {
  if (!origin) return false;
  return config.cors.allowedOrigins.includes(origin);
}
function getSecurityHeaders(config, origin) {
  const headers = {
    ...config.headers.security,
    ...config.headers.cache
  };
  if (origin && validateOrigin(origin, config)) {
    headers["Access-Control-Allow-Origin"] = origin;
    headers["Access-Control-Allow-Methods"] = config.cors.allowedMethods.join(", ");
    headers["Access-Control-Allow-Headers"] = config.cors.allowedHeaders.join(", ");
    headers["Access-Control-Max-Age"] = config.cors.maxAge.toString();
    if (config.cors.credentials) {
      headers["Access-Control-Allow-Credentials"] = "true";
    }
  }
  return headers;
}
function validateRequest(request, clientIP, config) {
  const origin = request.headers.get("origin");
  const userAgent = request.headers.get("user-agent");
  const contentType = request.headers.get("content-type");
  if (origin && !validateOrigin(origin, config)) {
    return {
      valid: false,
      reason: "Invalid origin",
      shouldBlock: true,
      shouldLog: true
    };
  }
  if (config.validation.requireUserAgent && !userAgent) {
    return {
      valid: false,
      reason: "Missing User-Agent header",
      shouldBlock: config.validation.enableStrictValidation,
      shouldLog: true
    };
  }
  if (request.method === "POST") {
    if (!contentType || !contentType.includes("application/json")) {
      return {
        valid: false,
        reason: "Invalid Content-Type",
        shouldBlock: config.validation.enableStrictValidation,
        shouldLog: true
      };
    }
  }
  if (userAgent) {
    const suspiciousPatterns = [
      /bot/i,
      /crawler/i,
      /spider/i,
      /scraper/i,
      /wget/i,
      /curl/i
    ];
    const isSuspicious = suspiciousPatterns.some((pattern) => pattern.test(userAgent));
    if (isSuspicious && config.validation.enableStrictValidation) {
      return {
        valid: false,
        reason: "Suspicious User-Agent",
        shouldBlock: false,
        shouldLog: true
      };
    }
  }
  return { valid: true };
}
class SecurityAuditor {
  static logs = [];
  static MAX_LOGS = 1e3;
  /**
   * Log security event
   */
  static log(event) {
    this.logs.push(event);
    if (this.logs.length > this.MAX_LOGS) {
      this.logs.shift();
    }
    if (event.severity === "high" || event.severity === "critical") {
      console.warn(`🚨 Security Event [${event.severity.toUpperCase()}]: ${event.event}`, event);
    }
  }
  /**
   * Get recent security logs
   */
  static getLogs(limit = 100) {
    return this.logs.slice(-limit);
  }
  /**
   * Get logs by severity
   */
  static getLogsBySeverity(severity) {
    return this.logs.filter((log) => log.severity === severity);
  }
  /**
   * Clear old logs
   */
  static cleanup(retentionMs) {
    const cutoff = Date.now() - retentionMs;
    this.logs = this.logs.filter((log) => log.timestamp > cutoff);
  }
}

class SecureKeyManager {
  constructor(config) {
    this.config = config;
    this.initializeRotationScheduler();
    this.startUsageMonitoring();
  }
  keys = /* @__PURE__ */ new Map();
  usageHistory = [];
  rotationTimer = null;
  algorithm = "aes-256-gcm";
  /**
   * Encrypt API key using AES-256-GCM
   */
  encrypt(plaintext) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipher(this.algorithm, this.config.encryptionKey);
    cipher.setAAD(Buffer.from("apikey"));
    let encrypted = cipher.update(plaintext, "utf8", "hex");
    encrypted += cipher.final("hex");
    const tag = cipher.getAuthTag();
    return {
      encrypted,
      iv: iv.toString("hex"),
      tag: tag.toString("hex")
    };
  }
  /**
   * Decrypt API key using AES-256-GCM
   */
  decrypt(encryptedData) {
    const decipher = crypto.createDecipher(this.algorithm, this.config.encryptionKey);
    decipher.setAAD(Buffer.from("apikey"));
    decipher.setAuthTag(Buffer.from(encryptedData.tag, "hex"));
    let decrypted = decipher.update(encryptedData.encrypted, "hex", "utf8");
    decrypted += decipher.final("utf8");
    return decrypted;
  }
  /**
   * Generate secure key ID
   */
  generateKeyId() {
    return `key_${crypto.randomBytes(16).toString("hex")}`;
  }
  /**
   * Generate request signature for additional security
   */
  generateRequestSignature(keyId, timestamp, clientIP, operation) {
    const payload = `${keyId}:${timestamp}:${clientIP}:${operation}`;
    return crypto.createHmac("sha256", this.config.encryptionKey).update(payload).digest("hex");
  }
  /**
   * Verify request signature
   */
  verifyRequestSignature(signature, keyId, timestamp, clientIP, operation) {
    const expectedSignature = this.generateRequestSignature(keyId, timestamp, clientIP, operation);
    return crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedSignature));
  }
  /**
   * Store API key securely with encryption
   */
  storeKey(plainApiKey, environment = "production") {
    const keyId = this.generateKeyId();
    const encryptedKey = this.encrypt(plainApiKey);
    const metadata = {
      keyId,
      createdAt: Date.now(),
      lastUsed: 0,
      usageCount: 0,
      isActive: true,
      environment
    };
    this.keys.set(keyId, {
      encrypted: JSON.stringify(encryptedKey),
      metadata
    });
    if (this.config.enableAutoRotation) {
      metadata.rotationScheduled = Date.now() + this.config.keyRotationIntervalHours * 60 * 60 * 1e3;
    }
    SecurityAuditor.log({
      timestamp: Date.now(),
      event: "API_KEY_STORED",
      clientIP: "system",
      details: { keyId, environment },
      severity: "medium"
    });
    console.log(`🔐 API key stored securely: ${keyId} (${environment})`);
    return keyId;
  }
  /**
   * Retrieve and decrypt API key with usage tracking
   */
  getKey(keyId, clientIP, operation, requestSignature) {
    const keyData = this.keys.get(keyId);
    if (!keyData || !keyData.metadata.isActive) {
      this.logUsageEvent(keyId, clientIP, operation, false, "KEY_NOT_FOUND");
      return null;
    }
    if (requestSignature) {
      const isValidSignature = this.verifyRequestSignature(
        requestSignature,
        keyId,
        Date.now(),
        clientIP,
        operation
      );
      if (!isValidSignature) {
        this.logUsageEvent(keyId, clientIP, operation, false, "INVALID_SIGNATURE");
        SecurityAuditor.log({
          timestamp: Date.now(),
          event: "INVALID_REQUEST_SIGNATURE",
          clientIP,
          details: { keyId, operation },
          severity: "high"
        });
        return null;
      }
    }
    if (this.isKeyExpired(keyData.metadata)) {
      this.deactivateKey(keyId, "EXPIRED");
      this.logUsageEvent(keyId, clientIP, operation, false, "KEY_EXPIRED");
      return null;
    }
    try {
      const encryptedData = JSON.parse(keyData.encrypted);
      const plainKey = this.decrypt(encryptedData);
      keyData.metadata.lastUsed = Date.now();
      keyData.metadata.usageCount++;
      this.logUsageEvent(keyId, clientIP, operation, true);
      this.checkUsagePatterns(keyId, clientIP);
      return plainKey;
    } catch (error) {
      this.logUsageEvent(keyId, clientIP, operation, false, "DECRYPTION_ERROR");
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "KEY_DECRYPTION_FAILED",
        clientIP,
        details: { keyId, error: error instanceof Error ? error.message : "Unknown error" },
        severity: "critical"
      });
      return null;
    }
  }
  /**
   * Check for unusual usage patterns and flag suspicious activity
   */
  checkUsagePatterns(keyId, clientIP) {
    const recentEvents = this.usageHistory.filter(
      (event) => event.keyId === keyId && event.timestamp > Date.now() - 6e4 && // Last minute
      event.clientIP === clientIP
    );
    const requestCount = recentEvents.length;
    const errorRate = recentEvents.filter((event) => !event.success).length / requestCount;
    if (requestCount > this.config.alertThresholds.unusualUsage) {
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "UNUSUAL_USAGE_PATTERN",
        clientIP,
        details: { keyId, requestCount, timeWindow: "1m" },
        severity: "medium"
      });
    }
    if (errorRate > this.config.alertThresholds.errorRate) {
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "HIGH_ERROR_RATE",
        clientIP,
        details: { keyId, errorRate, requestCount },
        severity: "high"
      });
    }
    const failedAttempts = recentEvents.filter((event) => !event.success).length;
    if (failedAttempts > this.config.alertThresholds.suspiciousActivity) {
      this.temporarilyBlockKey(keyId, 3e5);
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "SUSPICIOUS_ACTIVITY_DETECTED",
        clientIP,
        details: { keyId, failedAttempts, action: "key_temporarily_blocked" },
        severity: "critical"
      });
    }
  }
  /**
   * Log key usage event
   */
  logUsageEvent(keyId, clientIP, operation, success, errorCode) {
    const event = {
      timestamp: Date.now(),
      keyId,
      clientIP,
      operation,
      success,
      errorCode,
      requestSignature: this.generateRequestSignature(keyId, Date.now(), clientIP, operation)
    };
    this.usageHistory.push(event);
    const cutoff = Date.now() - 24 * 60 * 60 * 1e3;
    this.usageHistory = this.usageHistory.filter((e) => e.timestamp > cutoff);
    if (this.config.enableUsageMonitoring) {
      console.log(`📊 Key usage: ${keyId} | ${operation} | ${success ? "✅" : "❌"} | ${clientIP}`);
    }
  }
  /**
   * Check if key has expired
   */
  isKeyExpired(metadata) {
    return Date.now() - metadata.createdAt > this.config.maxKeyAge;
  }
  /**
   * Deactivate key with reason
   */
  deactivateKey(keyId, reason) {
    const keyData = this.keys.get(keyId);
    if (keyData) {
      keyData.metadata.isActive = false;
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "API_KEY_DEACTIVATED",
        clientIP: "system",
        details: { keyId, reason },
        severity: "medium"
      });
      console.log(`🚫 API key deactivated: ${keyId} (${reason})`);
    }
  }
  /**
   * Temporarily block key for security purposes
   */
  temporarilyBlockKey(keyId, durationMs) {
    this.deactivateKey(keyId, "TEMPORARY_SECURITY_BLOCK");
    setTimeout(() => {
      const keyData = this.keys.get(keyId);
      if (keyData) {
        keyData.metadata.isActive = true;
        console.log(`🔓 API key unblocked: ${keyId}`);
      }
    }, durationMs);
  }
  /**
   * Rotate API key (manual trigger)
   */
  async rotateKey(keyId, newPlainKey) {
    const oldKeyData = this.keys.get(keyId);
    if (!oldKeyData) {
      throw new Error(`Key ${keyId} not found`);
    }
    const newKeyId = this.storeKey(newPlainKey, oldKeyData.metadata.environment);
    setTimeout(() => {
      this.deactivateKey(keyId, "ROTATED");
    }, 3e4);
    SecurityAuditor.log({
      timestamp: Date.now(),
      event: "API_KEY_ROTATED",
      clientIP: "system",
      details: { oldKeyId: keyId, newKeyId },
      severity: "low"
    });
    console.log(`🔄 API key rotated: ${keyId} → ${newKeyId}`);
    return newKeyId;
  }
  /**
   * Initialize automatic key rotation scheduler
   */
  initializeRotationScheduler() {
    if (!this.config.enableAutoRotation) return;
    this.rotationTimer = setInterval(() => {
      const now = Date.now();
      for (const [keyId, keyData] of this.keys.entries()) {
        if (keyData.metadata.rotationScheduled && now >= keyData.metadata.rotationScheduled) {
          console.log(`⚠️ API key ${keyId} requires rotation - manual intervention needed`);
          SecurityAuditor.log({
            timestamp: Date.now(),
            event: "API_KEY_ROTATION_REQUIRED",
            clientIP: "system",
            details: { keyId, environment: keyData.metadata.environment },
            severity: "medium"
          });
        }
      }
    }, 6e4);
  }
  /**
   * Start usage monitoring
   */
  startUsageMonitoring() {
    if (!this.config.enableUsageMonitoring) return;
    setInterval(() => {
      const report = this.generateUsageReport();
      console.log("📈 API Key Usage Report:", report);
    }, 60 * 60 * 1e3);
  }
  /**
   * Generate usage report
   */
  generateUsageReport() {
    const totalKeys = this.keys.size;
    const activeKeys = Array.from(this.keys.values()).filter((k) => k.metadata.isActive).length;
    const totalRequests = this.usageHistory.length;
    const successfulRequests = this.usageHistory.filter((e) => e.success).length;
    const successRate = totalRequests > 0 ? successfulRequests / totalRequests * 100 : 0;
    const operationCounts = /* @__PURE__ */ new Map();
    this.usageHistory.forEach((event) => {
      const count = operationCounts.get(event.operation) || 0;
      operationCounts.set(event.operation, count + 1);
    });
    const topOperations = Array.from(operationCounts.entries()).map(([operation, count]) => ({ operation, count })).sort((a, b) => b.count - a.count).slice(0, 5);
    return {
      totalKeys,
      activeKeys,
      totalRequests,
      successRate,
      topOperations
    };
  }
  /**
   * Get key metadata (for monitoring)
   */
  getKeyMetadata(keyId) {
    const keyData = this.keys.get(keyId);
    return keyData ? { ...keyData.metadata } : null;
  }
  /**
   * List all active keys (metadata only)
   */
  listActiveKeys() {
    return Array.from(this.keys.values()).filter((k) => k.metadata.isActive).map((k) => ({ ...k.metadata }));
  }
  /**
   * Cleanup expired and inactive keys
   */
  cleanup() {
    const now = Date.now();
    const expiredKeyIds = [];
    for (const [keyId, keyData] of this.keys.entries()) {
      if (!keyData.metadata.isActive && now - keyData.metadata.lastUsed > 7 * 24 * 60 * 60 * 1e3) {
        expiredKeyIds.push(keyId);
      }
    }
    expiredKeyIds.forEach((keyId) => {
      this.keys.delete(keyId);
      console.log(`🗑️ Removed expired key: ${keyId}`);
    });
    const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1e3;
    this.usageHistory = this.usageHistory.filter((e) => e.timestamp > cutoff);
    if (expiredKeyIds.length > 0) {
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "EXPIRED_KEYS_CLEANED",
        clientIP: "system",
        details: { removedCount: expiredKeyIds.length },
        severity: "low"
      });
    }
  }
  /**
   * Destroy manager and cleanup resources
   */
  destroy() {
    if (this.rotationTimer) {
      clearInterval(this.rotationTimer);
    }
    this.keys.clear();
    this.usageHistory = [];
    console.log("🧹 SecureKeyManager destroyed");
  }
}
const DEFAULT_KEY_CONFIGS = {
  development: {
    encryptionKey: process.env.KEY_ENCRYPTION_SECRET || crypto.randomBytes(32).toString("hex"),
    keyRotationIntervalHours: 24 * 7,
    // 1 week
    maxKeyAge: 24 * 60 * 60 * 1e3 * 30,
    // 30 days
    enableAutoRotation: false,
    enableUsageMonitoring: true,
    alertThresholds: {
      unusualUsage: 100,
      suspiciousActivity: 10,
      errorRate: 0.5
    }
  },
  production: {
    encryptionKey: process.env.KEY_ENCRYPTION_SECRET,
    keyRotationIntervalHours: 24 * 3,
    // 3 days
    maxKeyAge: 24 * 60 * 60 * 1e3 * 7,
    // 7 days
    enableAutoRotation: true,
    enableUsageMonitoring: true,
    alertThresholds: {
      unusualUsage: 50,
      suspiciousActivity: 5,
      errorRate: 0.3
    }
  }
};
let keyManagerInstance = null;
function getKeyManager(environment = "production") {
  if (!keyManagerInstance) {
    const config = DEFAULT_KEY_CONFIGS[environment];
    keyManagerInstance = new SecureKeyManager(config);
  }
  return keyManagerInstance;
}

class SecureAPIProxy {
  constructor(config) {
    this.config = config;
    this.requestSigningKey = process.env.PROXY_SIGNING_KEY || crypto.randomBytes(32).toString("hex");
  }
  responseCache = /* @__PURE__ */ new Map();
  requestSigningKey;
  /**
   * Generate request signature for client
   */
  generateRequestSignature(sessionId, requestId, method, endpoint, body, timestamp) {
    const payload = JSON.stringify({
      sessionId,
      requestId,
      method,
      endpoint,
      body: body ? JSON.stringify(body) : "",
      timestamp
    });
    return crypto.createHmac("sha256", this.requestSigningKey).update(payload).digest("hex");
  }
  /**
   * Verify request signature
   */
  verifyRequestSignature(request) {
    if (!this.config.enableRequestSigning) return true;
    const expectedSignature = this.generateRequestSignature(
      request.sessionId,
      request.requestId,
      request.method,
      request.endpoint,
      request.body,
      request.timestamp
    );
    const isValid = crypto.timingSafeEqual(
      Buffer.from(request.signature, "hex"),
      Buffer.from(expectedSignature, "hex")
    );
    if (!isValid) {
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "INVALID_PROXY_SIGNATURE",
        clientIP: "proxy",
        details: { sessionId: request.sessionId, requestId: request.requestId },
        severity: "high"
      });
    }
    return isValid;
  }
  /**
   * Check if endpoint is allowed
   */
  isEndpointAllowed(endpoint) {
    return this.config.allowedEndpoints.some(
      (allowed) => endpoint.startsWith(allowed) || new RegExp(allowed).test(endpoint)
    );
  }
  /**
   * Get cached response if available and valid
   */
  getCachedResponse(cacheKey) {
    if (!this.config.enableResponseCaching) return null;
    const cached = this.responseCache.get(cacheKey);
    if (cached && Date.now() < cached.expires) {
      return cached.data;
    }
    if (cached) {
      this.responseCache.delete(cacheKey);
    }
    return null;
  }
  /**
   * Cache response
   */
  cacheResponse(cacheKey, data) {
    if (!this.config.enableResponseCaching) return;
    this.responseCache.set(cacheKey, {
      data,
      expires: Date.now() + this.config.cacheExpirationMs
    });
  }
  /**
   * Proxy OpenAI Chat Completions request
   */
  async proxyChatCompletions(body, sessionId) {
    const keyManager = getKeyManager();
    const apiKey = keyManager.getKey(
      "openai_primary",
      // Assuming we store the key with this ID
      "proxy-server",
      "chat-completion"
    );
    if (!apiKey) {
      throw new Error("API key not available");
    }
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "User-Agent": "ExecutiveAI-Proxy/1.0"
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI API error: ${response.status} - ${errorText}`);
    }
    return await response.json();
  }
  /**
   * Proxy OpenAI Text-to-Speech request
   */
  async proxyTextToSpeech(body, sessionId) {
    const keyManager = getKeyManager();
    const apiKey = keyManager.getKey(
      "openai_primary",
      "proxy-server",
      "text-to-speech"
    );
    if (!apiKey) {
      throw new Error("API key not available");
    }
    const response = await fetch("https://api.openai.com/v1/audio/speech", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
        "User-Agent": "ExecutiveAI-Proxy/1.0"
      },
      body: JSON.stringify(body)
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI TTS API error: ${response.status} - ${errorText}`);
    }
    return await response.arrayBuffer();
  }
  /**
   * Proxy OpenAI Speech-to-Text request
   */
  async proxySpeechToText(formData, sessionId) {
    const keyManager = getKeyManager();
    const apiKey = keyManager.getKey(
      "openai_primary",
      "proxy-server",
      "speech-to-text"
    );
    if (!apiKey) {
      throw new Error("API key not available");
    }
    const response = await fetch("https://api.openai.com/v1/audio/transcriptions", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "User-Agent": "ExecutiveAI-Proxy/1.0"
        // Note: Don't set Content-Type for FormData, let fetch set it with boundary
      },
      body: formData
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`OpenAI STT API error: ${response.status} - ${errorText}`);
    }
    return await response.json();
  }
  /**
   * Process proxy request
   */
  async processRequest(request, clientIP) {
    const startTime = Date.now();
    try {
      if (!this.verifyRequestSignature(request)) {
        return {
          success: false,
          error: "Invalid request signature",
          requestId: request.requestId,
          processingTime: Date.now() - startTime,
          mode: "proxy"
        };
      }
      const timeDiff = Date.now() - request.timestamp;
      if (timeDiff > 3e5) {
        return {
          success: false,
          error: "Request timestamp too old",
          requestId: request.requestId,
          processingTime: Date.now() - startTime,
          mode: "proxy"
        };
      }
      if (!this.isEndpointAllowed(request.endpoint)) {
        SecurityAuditor.log({
          timestamp: Date.now(),
          event: "BLOCKED_PROXY_ENDPOINT",
          clientIP,
          details: {
            endpoint: request.endpoint,
            sessionId: request.sessionId,
            requestId: request.requestId
          },
          severity: "medium"
        });
        return {
          success: false,
          error: "Endpoint not allowed",
          requestId: request.requestId,
          processingTime: Date.now() - startTime,
          mode: "proxy"
        };
      }
      const requestSize = JSON.stringify(request.body || {}).length;
      if (requestSize > this.config.maxRequestSize) {
        return {
          success: false,
          error: "Request too large",
          requestId: request.requestId,
          processingTime: Date.now() - startTime,
          mode: "proxy"
        };
      }
      const cacheKey = `${request.endpoint}:${crypto.createHash("sha256").update(JSON.stringify(request.body)).digest("hex")}`;
      const cachedResult = this.getCachedResponse(cacheKey);
      if (cachedResult) {
        return {
          success: true,
          data: cachedResult,
          requestId: request.requestId,
          processingTime: Date.now() - startTime,
          mode: "proxy"
        };
      }
      let result;
      if (request.endpoint === "/v1/chat/completions") {
        result = await this.proxyChatCompletions(request.body, request.sessionId);
      } else if (request.endpoint === "/v1/audio/speech") {
        const audioBuffer = await this.proxyTextToSpeech(request.body, request.sessionId);
        result = {
          audio: Buffer.from(audioBuffer).toString("base64"),
          contentType: "audio/mpeg"
        };
      } else if (request.endpoint === "/v1/audio/transcriptions") {
        result = await this.proxySpeechToText(request.body, request.sessionId);
      } else {
        return {
          success: false,
          error: "Unsupported endpoint",
          requestId: request.requestId,
          processingTime: Date.now() - startTime,
          mode: "proxy"
        };
      }
      this.cacheResponse(cacheKey, result);
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "SUCCESSFUL_PROXY_REQUEST",
        clientIP,
        details: {
          endpoint: request.endpoint,
          sessionId: request.sessionId,
          requestId: request.requestId,
          processingTime: Date.now() - startTime
        },
        severity: "low"
      });
      return {
        success: true,
        data: result,
        requestId: request.requestId,
        processingTime: Date.now() - startTime,
        mode: "proxy"
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      SecurityAuditor.log({
        timestamp: Date.now(),
        event: "PROXY_REQUEST_ERROR",
        clientIP,
        details: {
          endpoint: request.endpoint,
          sessionId: request.sessionId,
          requestId: request.requestId,
          error: errorMessage
        },
        severity: "medium"
      });
      return {
        success: false,
        error: errorMessage,
        requestId: request.requestId,
        processingTime: Date.now() - startTime,
        mode: "proxy"
      };
    }
  }
  /**
   * Generate secure fallback token for proxy mode
   * Returns a proxy token that routes through our secure proxy
   */
  generateSecureProxyToken(sessionId) {
    const proxyToken = crypto.createHmac("sha256", this.requestSigningKey).update(`${sessionId}:${Date.now()}:proxy`).digest("hex");
    return {
      token: `proxy_${proxyToken}`,
      expiresAt: Date.now() + 30 * 60 * 1e3,
      // 30 minutes
      mode: "proxy",
      proxyEndpoint: "/api/voice-agent/proxy"
    };
  }
  /**
   * Cleanup expired cache entries
   */
  cleanup() {
    const now = Date.now();
    for (const [key, cached] of this.responseCache.entries()) {
      if (now >= cached.expires) {
        this.responseCache.delete(key);
      }
    }
  }
  /**
   * Get proxy statistics
   */
  getStats() {
    return {
      cacheSize: this.responseCache.size,
      cacheHitRate: 0,
      // Would track hits/misses
      requestsProcessed: 0
      // Would track total requests
    };
  }
}
const DEFAULT_PROXY_CONFIG = {
  maxRequestSize: 1024 * 1024,
  // 1MB
  requestTimeoutMs: 3e4,
  // 30 seconds
  enableRequestSigning: true,
  enableResponseCaching: true,
  cacheExpirationMs: 5 * 60 * 1e3,
  // 5 minutes
  allowedEndpoints: [
    "/v1/chat/completions",
    "/v1/audio/speech",
    "/v1/audio/transcriptions"
  ]
};
let proxyInstance = null;
function getSecureProxy(config = DEFAULT_PROXY_CONFIG) {
  if (!proxyInstance) {
    proxyInstance = new SecureAPIProxy(config);
  }
  return proxyInstance;
}

export { SecurityAuditor as S, getSecureProxy as a, getSecurityHeaders as b, getKeyManager as c, getSecurityConfig as g, validateRequest as v };
