import { e as createComponent, f as createAstro, m as maybeRenderHead, h as addAttribute, n as renderSlot, l as renderScript, r as renderTemplate } from './astro/server_BUcCHCB2.mjs';
import 'kleur/colors';
import 'clsx';
/* empty css                         */

const $$Astro = createAstro();
const $$AnimatedSection = createComponent(($$result, $$props, $$slots) => {
  const Astro2 = $$result.createAstro($$Astro, $$props, $$slots);
  Astro2.self = $$AnimatedSection;
  const { class: className = "", animate = "fade", delay = 0, id } = Astro2.props;
  const animationClass = {
    fade: "animate-fade",
    slide: "animate-slide",
    scale: "animate-scale"
  }[animate];
  return renderTemplate`${maybeRenderHead()}<div${addAttribute(`animated-section opacity-0 ${animationClass} ${className}`, "class")}${addAttribute(delay, "data-delay")}${addAttribute(id, "id")} data-astro-cid-hszirhhi> ${renderSlot($$result, $$slots["default"])} </div>  ${renderScript($$result, "/home/dreamforge/ai_masterclass/executive-ai-training/src/components/AnimatedSection.astro?astro&type=script&index=0&lang.ts")}`;
}, "/home/dreamforge/ai_masterclass/executive-ai-training/src/components/AnimatedSection.astro", void 0);

export { $$AnimatedSection as $ };
