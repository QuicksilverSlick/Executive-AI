import { c as createTokenRateLimiter, b as createRateLimitMiddleware } from './rateLimiter_B7mgpYIE.mjs';

const prerender = false;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
const ALLOWED_ORIGINS = process.env.ALLOWED_ORIGINS?.split(",") || [
  "http://localhost:4321",
  "http://localhost:4322",
  "https://executiveaitraining.com"
];
if (!OPENAI_API_KEY) {
  console.error("❌ OPENAI_API_KEY environment variable is required");
}
const refreshRateLimiter = createTokenRateLimiter({
  windowMs: 60 * 1e3,
  // 1 minute window
  maxRequests: process.env.DEV ? 20 : 5,
  // More lenient in development
  onLimitReached: (clientIP, attempts) => {
    const isDev = process.env.DEV || process.env.NODE_ENV === "development";
    if (isDev) {
      console.log(`ℹ️ Token refresh rate limit reached for ${clientIP} - Attempts: ${attempts} (Development mode)`);
    } else {
      console.warn(`🚫 Token refresh rate limit exceeded for ${clientIP} - Attempts: ${attempts}`);
    }
  }
});
const activeSessions = /* @__PURE__ */ new Map();
setInterval(() => {
  const now = Date.now();
  const expiredSessions = [];
  for (const [sessionId, session] of activeSessions.entries()) {
    if (now - session.createdAt > 10 * 60 * 1e3 || session.refreshCount > 20) {
      expiredSessions.push(sessionId);
    }
  }
  expiredSessions.forEach((sessionId) => {
    activeSessions.delete(sessionId);
  });
  if (expiredSessions.length > 0) {
    console.log(`🧹 Cleaned up ${expiredSessions.length} expired sessions`);
  }
}, 5 * 60 * 1e3);
function validateRefreshRequest(sessionId, clientIP) {
  if (!sessionId || typeof sessionId !== "string") {
    return { valid: false, reason: "Invalid session ID" };
  }
  const session = activeSessions.get(sessionId);
  if (!session) {
    return { valid: false, reason: "Session not found or expired" };
  }
  if (session.clientIP !== clientIP) {
    console.warn(`🚨 Session hijacking attempt: Session ${sessionId} from ${clientIP}, expected ${session.clientIP}`);
    return { valid: false, reason: "Session validation failed" };
  }
  const now = Date.now();
  const minRefreshInterval = 30 * 1e3;
  if (now - session.lastRefresh < minRefreshInterval) {
    return { valid: false, reason: "Refresh too frequent" };
  }
  return { valid: true };
}
async function generateEphemeralToken() {
  const response = await fetch("https://api.openai.com/v1/realtime/sessions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${OPENAI_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model: "gpt-4o-realtime-preview",
      voice: "alloy",
      expires_at: Math.floor(Date.now() / 1e3) + 60
      // 60 seconds from now
    })
  });
  if (!response.ok) {
    const errorText = await response.text();
    console.error("OpenAI token generation failed:", response.status, errorText);
    throw new Error(`Token generation failed: ${response.status}`);
  }
  const data = await response.json();
  return {
    token: data.client_secret.value,
    expiresAt: data.expires_at * 1e3
    // Convert to milliseconds
  };
}
const POST = async ({ request, clientAddress }) => {
  const startTime = Date.now();
  const clientIP = clientAddress || request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown";
  const userAgent = request.headers.get("user-agent") || "unknown";
  const origin = request.headers.get("origin");
  console.log(`🔄 Token refresh request from ${clientIP} - ${userAgent} - Origin: ${origin}`);
  try {
    if (origin && !ALLOWED_ORIGINS.includes(origin)) {
      console.warn(`❌ Invalid origin for refresh: ${origin} from ${clientIP}`);
      return new Response(JSON.stringify({
        success: false,
        error: "Invalid origin"
      }), {
        status: 403,
        headers: { "Content-Type": "application/json" }
      });
    }
    const rateLimitMiddleware = createRateLimitMiddleware(refreshRateLimiter);
    const rateLimitResponse = rateLimitMiddleware(request, clientIP);
    if (rateLimitResponse) {
      return rateLimitResponse;
    }
    if (!OPENAI_API_KEY) {
      console.error("❌ OpenAI API key not configured for refresh");
      return new Response(JSON.stringify({
        success: false,
        error: "Service temporarily unavailable"
      }), {
        status: 503,
        headers: { "Content-Type": "application/json" }
      });
    }
    let requestBody;
    try {
      requestBody = await request.json();
    } catch (error) {
      return new Response(JSON.stringify({
        success: false,
        error: "Invalid request body"
      }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const { sessionId } = requestBody;
    const validation = validateRefreshRequest(sessionId, clientIP);
    if (!validation.valid) {
      console.warn(`❌ Invalid refresh request from ${clientIP}: ${validation.reason}`);
      return new Response(JSON.stringify({
        success: false,
        error: validation.reason
      }), {
        status: 400,
        headers: { "Content-Type": "application/json" }
      });
    }
    const { token, expiresAt } = await generateEphemeralToken();
    const session = activeSessions.get(sessionId);
    session.lastRefresh = Date.now();
    session.refreshCount++;
    const response = {
      success: true,
      token,
      expiresAt,
      sessionId
    };
    const processingTime = Date.now() - startTime;
    console.log(`✅ Token refreshed for ${clientIP} - Session: ${sessionId} - Refresh #${session.refreshCount} - Processing: ${processingTime}ms`);
    return new Response(JSON.stringify(response), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "X-Processing-Time": processingTime.toString(),
        "X-Refresh-Count": session.refreshCount.toString(),
        ...origin && ALLOWED_ORIGINS.includes(origin) && {
          "Access-Control-Allow-Origin": origin,
          "Access-Control-Allow-Methods": "POST",
          "Access-Control-Allow-Headers": "Content-Type, Authorization"
        }
      }
    });
  } catch (error) {
    const processingTime = Date.now() - startTime;
    console.error(`❌ Token refresh error for ${clientIP}:`, error);
    return new Response(JSON.stringify({
      success: false,
      error: "Token refresh failed"
    }), {
      status: 500,
      headers: {
        "Content-Type": "application/json",
        "X-Processing-Time": processingTime.toString()
      }
    });
  }
};
const OPTIONS = async ({ request }) => {
  const origin = request.headers.get("origin");
  if (origin && ALLOWED_ORIGINS.includes(origin)) {
    return new Response(null, {
      status: 200,
      headers: {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Max-Age": "86400"
        // 24 hours
      }
    });
  }
  return new Response(null, { status: 404 });
};
function registerSession(sessionId, clientIP) {
  activeSessions.set(sessionId, {
    sessionId,
    clientIP,
    createdAt: Date.now(),
    lastRefresh: Date.now(),
    refreshCount: 0
  });
  console.log(`📝 Registered new session: ${sessionId} from ${clientIP}`);
}
function getSessionStats() {
  let totalRefreshes = 0;
  for (const session of activeSessions.values()) {
    totalRefreshes += session.refreshCount;
  }
  return {
    activeSessions: activeSessions.size,
    totalRefreshes
  };
}

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
  __proto__: null,
  OPTIONS,
  POST,
  getSessionStats,
  prerender,
  registerSession
}, Symbol.toStringTag, { value: 'Module' }));

export { _page as _, getSessionStats as g, registerSession as r };
