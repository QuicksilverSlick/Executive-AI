/* empty css                                 */
export { renderers } from '../renderers.mjs';

function render({ slots: ___SLOTS___ }) {
		return `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Production Voice Agent Test</title>
    <style>
        body {
            font-family: system-ui, -apple-system, sans-serif;
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
            background: #1a1a1a;
            color: #fff;
        }
        .test-container {
            background: #2a2a2a;
            border-radius: 10px;
            padding: 30px;
            margin-bottom: 20px;
        }
        button {
            background: #4CAF50;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-right: 10px;
            margin-bottom: 10px;
        }
        button:hover {
            background: #45a049;
        }
        button:disabled {
            background: #666;
            cursor: not-allowed;
        }
        .result {
            background: #333;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            font-family: monospace;
            white-space: pre-wrap;
            max-height: 400px;
            overflow-y: auto;
        }
        .success {
            border-left: 4px solid #4CAF50;
        }
        .error {
            border-left: 4px solid #f44336;
        }
        .info {
            border-left: 4px solid #2196F3;
        }
        h1 {
            color: #fff;
        }
        h2 {
            color: #ddd;
            font-size: 18px;
            margin-bottom: 15px;
        }
        .status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 3px;
            margin-left: 10px;
            font-size: 14px;
        }
        .status.active {
            background: #4CAF50;
        }
        .status.inactive {
            background: #f44336;
        }
    </style>
</head>
<body>
    <h1>🎙️ Voice Agent Production Test</h1>
    
    <div class="test-container">
        <h2>Environment Status</h2>
        <div>
            <strong>Production Server:</strong> 
            <span class="status active">http://localhost:4321</span>
        </div>
        <div>
            <strong>Search Server (Dev):</strong> 
            <span class="status active">http://localhost:3001</span>
        </div>
        <div id="environment"></div>
    </div>

    <div class="test-container">
        <h2>Test Search API (Production Route)</h2>
        <button onclick="testSearchAPI()">Test Astro API Route</button>
        <button onclick="testSearchServer()">Test Standalone Server</button>
        <div id="searchResult" class="result"></div>
    </div>

    <div class="test-container">
        <h2>Test Voice Agent Integration</h2>
        <button onclick="testTokenEndpoint()">Test Token Generation</button>
        <button onclick="openVoiceAgent()">Open Voice Agent</button>
        <div id="voiceResult" class="result"></div>
    </div>

    <script>
        // Check environment
        function checkEnvironment() {
            const isProd = window.location.port === '4321';
            const env = document.getElementById('environment');
            env.innerHTML = \`<strong>Mode:</strong> <span class="status \${isProd ? 'active' : 'inactive'}">\${isProd ? 'PRODUCTION BUILD' : 'DEVELOPMENT'}</span>\`;
        }

        // Test the Astro API route
        async function testSearchAPI() {
            const result = document.getElementById('searchResult');
            result.className = 'result info';
            result.textContent = 'Testing Astro API route...';
            
            try {
                const response = await fetch('/api/voice-agent/responses-search?query=OpenAI%20latest%20news');
                const data = await response.json();
                
                result.className = 'result success';
                result.textContent = \`✅ Astro API Route Working!\\n\\nResponse:\\n\${JSON.stringify(data, null, 2)}\`;
            } catch (error) {
                result.className = 'result error';
                result.textContent = \`❌ Astro API Route Error:\\n\${error.message}\`;
            }
        }

        // Test the standalone search server
        async function testSearchServer() {
            const result = document.getElementById('searchResult');
            result.className = 'result info';
            result.textContent = 'Testing standalone search server...';
            
            try {
                const response = await fetch('http://localhost:3001/search?query=OpenAI%20latest%20news');
                const data = await response.json();
                
                result.className = 'result success';
                result.textContent = \`✅ Standalone Server Working!\\n\\nResponse:\\n\${JSON.stringify(data, null, 2)}\`;
            } catch (error) {
                result.className = 'result error';
                result.textContent = \`❌ Standalone Server Error:\\n\${error.message}\\n\\nMake sure the search server is running:\\n./start-search-server.sh\`;
            }
        }

        // Test token endpoint
        async function testTokenEndpoint() {
            const result = document.getElementById('voiceResult');
            result.className = 'result info';
            result.textContent = 'Testing token endpoint...';
            
            try {
                const response = await fetch('/api/voice-agent/token', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({})
                });
                const data = await response.json();
                
                if (data.client_secret && data.client_secret.value) {
                    result.className = 'result success';
                    result.textContent = \`✅ Token Endpoint Working!\\n\\nGenerated ephemeral token successfully.\\nToken starts with: \${data.client_secret.value.substring(0, 20)}...\`;
                } else {
                    throw new Error('Invalid token response');
                }
            } catch (error) {
                result.className = 'result error';
                result.textContent = \`❌ Token Endpoint Error:\\n\${error.message}\`;
            }
        }

        // Open voice agent page
        function openVoiceAgent() {
            window.open('/voice-agent', '_blank');
        }

        // Initialize
        checkEnvironment();
    </script>
</body>
</html>`
	}
render["astro:html"] = true;

const _page = /*#__PURE__*/Object.freeze(/*#__PURE__*/Object.defineProperty({
    __proto__: null,
    default: render
}, Symbol.toStringTag, { value: 'Module' }));

const page = () => _page;

export { page };
